var express = require('express');
var router = express.Router();
var dbCon = require('../lib/db');
var sha256 = require('js-sha256');


/* GET home page. */
router.get('/', function(req, res, next) {
  if (req.session.user_login){
    dbCon.query('SELECT * FROM users WHERE id = ?', [req.session.user_login], (err, rows) => {
      res.render('index', {
        username: rows[0].username
      });
    });
  } else {
    res.render('index', {
      username: ''
    });
  }
});

router.post('/', function(req, res, next) {

    let username = req.body.username_login;
    let password = req.body.password_login;

    var passwordhash = sha256.create();
    passwordhash.update(password);
    passwordhash.hex();

    dbCon.query('SELECT * FROM users WHERE username = ?', [username], (err, rows) => {
      if (rows.length > 0){
        if (err){
          req.flash('error', err);
        } else {
          if (rows[0].password == passwordhash){
            let id = rows[0].id;
            req.session.user_login = id;
            res.redirect('/');
          } else {
            req.flash('error', "username หรือ password ไม่ถูกต้อง");
            res.redirect('/');
          }
        } 
      } else {
        req.flash('error', "username หรือ password ไม่ถูกต้อง");
        res.redirect('/');
      }


    })

});

router.get('/logout', function(req, res, next) {
  req.session.destroy()
  res.redirect('/');

});


router.get('/confirm', function(req, res, next) {
  res.render('confirm');
});


router.get('/confirm-admin', function(req, res, next) {
  res.render('confirm_admin');
});

router.get('/booking', function(req, res, next) {
  res.render('booking');
});

router.get('/reservation-admin', function(req, res, next) {
  res.render('reservation-admin');
});

router.get('/room_type', function(req, res, next) {
  res.render('room_type');
});

router.get('/booked_admin', function(req, res, next) {
  res.render('booked_admin');
});

router.get('/user-selected', function(req, res, next) {
  res.render('user_selected');
});

router.get('/register', function(req, res, next) {
  res.render('register');
});

router.get('/reservation', function(req, res, next) {
  res.render('reservation');
});

router.get('/payment_system', function(req, res, next) {
  if(req.session.user_login) {
    dbCon.query("SELECT * FROM payment WHERE user_id = ?", [req.session.user_login], (err, result) =>{
      if(result.length > 0){
        res.render('payment_system', {
          data: result
        });
      } else {
        res.render('payment_system', {
          data: ''
        });
      }
    });
  } else {
    req.flash('error', 'โปรดล็อคอินก่อน');
    res.redirect('/');
  }

});

router.post('/pay', function(req, res, next) {
  let name = req.body.name;
  let number = req.body.number;
  let expiry = req.body.expiry;
  let cvv_cvc = req.body.cvv_cvc;
  let user_id = req.session.user_login;

    let form_data = {
      name: name,
      number: number,
      expiry: expiry,
      cvv_cvc: cvv_cvc,
      user_id: user_id
    }
    dbCon.query("INSERT INTO payment SET ?", form_data, (err, result) =>{
      if (err){
        req.flash('error', err);
        console.log(err);
        res.redirect('/payment_system');
      } else {
        req.flash('success', "เพิ่มบัตรเรียบร้อย");
        res.redirect('/payment_system');
      }

    });

});

router.post('/pay_confirm', function(req, res, next) {
  req.flash('success', 'ชำระเงินเรียบร้อย');
  res.redirect('/payment_system');

});

router.get('/booking_detail', function(req, res, next) {
  res.render('booking_detail');
});

router.get('/checking', function(req, res, next) {
  res.render('checking');
});

router.get('/checking_admin', function(req, res, next) {
  res.render('checking_admin');
});


router.post('/register', function(req, res, next) {
  let username = req.body.username;
  let password = req.body.password;
  let c_password = req.body.c_password;
  let email = req.body.email;
  let error = false;

  if (username.length < 6){
    error = true;
    req.flash('error', "username น้อยกว่า 6 ตัว");
    res.redirect('/register');
  } else if (password.length < 6){
    error = true;
    req.flash('error', "password น้อยกว่า 6 ตัว");
    res.redirect('/register');
  } else if (password != c_password){
    error = true;
    req.flash('error', "password ไม่ตรงกัน");
    res.redirect('/register');
  }
  if (!error){
    var passwordhash = sha256.create();
    passwordhash.update(password);
    passwordhash.hex();

    let form_data = {
      username: username,
      password: passwordhash,
      email: email,
    }
    dbCon.query("INSERT INTO users SET ?", form_data, (err, result) =>{
      if (err){
        req.flash('error', "มี username นี้ในระบบ");
        console.log(err);
        res.redirect('/register');
      } else {
        req.flash('success', "สมัครสมาชิกเรียบร้อย");
        res.redirect('/register');
      }

    });
  }
});

module.exports = router;
